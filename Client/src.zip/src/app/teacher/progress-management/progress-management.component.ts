import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { LoggingService } from '../../services/logging.service';
import { handleResponse } from '../../utils/handle-response.utils';

interface StudentProgressData {
  assignmentId: number;
  studentId: number;
  studentName: string;
  courseId: number;
  courseName: string;
  currentLevel: string;
  currentLevelId?: number;
  progress: number;
  status: string;
}

@Component({
  selector: 'app-progress-management',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './progress-management.component.html',
  styleUrls: ['./progress-management.component.css'],
})
export class ProgressManagementComponent implements OnInit {
  private apiService = inject(ApiService);
  private loggingService = inject(LoggingService);
  private router = inject(Router);

  // Data
  students = signal<any[]>([]);
  courses = signal<any[]>([]);
  assignments = signal<any[]>([]);
  levels = signal<Map<number, any[]>>(new Map());

  // Processed data
  progressData = signal<StudentProgressData[]>([]);
  isLoading = signal<boolean>(false);

  // Filters
  selectedCourseId = signal<number | null>(null);
  searchTerm = signal<string>('');

  // Computed filtered data
  filteredProgress = computed(() => {
    let filtered = this.progressData();

    if (this.selectedCourseId() !== null) {
      filtered = filtered.filter(
        (p) => p.courseId === this.selectedCourseId()!
      );
    }

    if (this.searchTerm().trim() !== '') {
      const term = this.searchTerm().toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.studentName.toLowerCase().includes(term) ||
          p.courseName.toLowerCase().includes(term)
      );
    }

    return filtered;
  });

  // Available courses for filter
  availableCourses = computed(() => {
    const courseIds = new Set(this.progressData().map((p) => p.courseId));
    return this.courses().filter((c) => courseIds.has(c.courseId));
  });

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.isLoading.set(true);

    // Load assignments
    this.apiService.getMyStudents().subscribe(
      handleResponse(
        this.loggingService,
        (data: any) => {
          this.assignments.set(Array.isArray(data) ? data : []);
          // Once assignments are loaded, derive students and courses
          this.extractCoursesFromAssignments();
          this.extractStudentsFromAssignments();
          this.processProgressData();
          this.checkLoadingComplete();
        },
        () => {
          this.assignments.set([]);
          this.checkLoadingComplete();
        }
      )
    );
  }

  extractStudentsFromAssignments() {
    const assignments = this.assignments();
    const uniqueStudentIds = new Set(assignments.map((a) => a.studentId));

    const studentsList: any[] = Array.from(uniqueStudentIds).map(
      (studentId) => ({
        userId: studentId,
        fullName: `Student ${studentId}`,
        name: `Student ${studentId}`,
      })
    );

    this.students.set(studentsList);
    this.processProgressData();
    this.checkLoadingComplete();
  }

  extractCoursesFromAssignments() {
    const assignments = this.assignments();
    const uniqueCourseIds = new Set(assignments.map((a) => a.courseId));

    const coursesList: any[] = Array.from(uniqueCourseIds).map((courseId) => {
      const assignmentForCourse = assignments.find(
        (a) => a.courseId === courseId
      );
      const courseName =
        assignmentForCourse?.courseName ||
        assignmentForCourse?.course?.courseName ||
        `Course ${courseId}`;

      return {
        courseId,
        courseName,
      };
    });

    this.courses.set(coursesList);

    uniqueCourseIds.forEach((courseId) => {
      this.loadLevelsForCourse(courseId as number);
    });
  }

  loadLevelsForCourse(courseId: number) {
    this.apiService.getLevelsByCourseForTeacher(courseId).subscribe(
      handleResponse(
        this.loggingService,
        (data: any) => {
          const levels = Array.isArray(data) ? data : [];
          this.levels.update((map) => {
            const newMap = new Map(map);
            newMap.set(courseId, levels);
            return newMap;
          });
          this.processProgressData();
        },
        () => {
          // Error loading levels
        }
      )
    );
  }

  processProgressData() {
    const assignments = this.assignments();
    const courses = this.courses();
    const students = this.students();
    const levelsMap = this.levels();

    const processed: StudentProgressData[] = assignments.map((assignment) => {
      const student = students.find((s) => s.userId === assignment.studentId);
      const studentName =
        student?.fullName || student?.name || `Student ${assignment.studentId}`;

      const course = courses.find((c) => c.courseId === assignment.courseId);
      const courseName = course?.courseName || `Course ${assignment.courseId}`;

      const courseLevels = levelsMap.get(assignment.courseId) || [];
      const currentLevel =
        courseLevels.length > 0 ? courseLevels[0].levelName : 'Not Started';
      const currentLevelId =
        courseLevels.length > 0 ? courseLevels[0].levelId : undefined;

      const progress = this.calculateProgress(
        assignment.studentId,
        assignment.courseId,
        courseLevels
      );

      return {
        assignmentId: assignment.assignmentId,
        studentId: assignment.studentId,
        studentName,
        courseId: assignment.courseId,
        courseName,
        currentLevel,
        currentLevelId,
        progress,
        status: assignment.status || 'ACTIVE',
      };
    });

    this.progressData.set(processed);
  }

  calculateProgress(
    studentId: number,
    courseId: number,
    levels: any[]
  ): number {
    if (levels.length === 0) return 0;
    return Math.floor(Math.random() * 100);
  }

  private checkLoadingComplete() {
    setTimeout(() => {
      this.isLoading.set(false);
    }, 300);
  }

  onCourseFilterChange(courseId: string) {
    this.selectedCourseId.set(courseId ? parseInt(courseId) : null);
  }

  onSearchChange(term: string) {
    this.searchTerm.set(term);
  }

  viewProgress(progress: StudentProgressData) {
    this.router.navigate([
      '/teacher/students',
      progress.studentId,
      'courses',
      progress.courseId,
      'progress',
    ]);
  }

  getStatusClass(status: string): string {
    switch (status?.toLowerCase()) {
      case 'completed':
        return 'status-completed';
      case 'in_progress':
        return 'status-in-progress';
      case 'not_started':
        return 'status-not-started';
      default:
        return 'status-active';
    }
  }
}
